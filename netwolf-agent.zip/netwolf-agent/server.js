"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");
const net = require("net");
const crypto = require("crypto");
const { spawn } = require("child_process");

const ROOT = __dirname;
const CONFIG_PATH = path.join(ROOT, "config.json");
const CHECKS_PATH = path.join(ROOT, "checks.json");
const LOG_DIR = path.join(ROOT, "logs");

const CHANGE_WORDS = [
  " config ", " edit ", " set ", " unset ", " delete ", " purge ", " execute reboot",
  " execute shutdown", " execute factoryreset", " diagnose debug enable", " diagnose debug flow",
  " diagnose sniffer packet", " execute restore", " execute backup", " formatlogdisk"
];

function readJson(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch (error) {
    return fallback;
  }
}

function loadConfig() {
  return Object.assign({
    mode: "local",
    bind: "127.0.0.1",
    port: 5051,
    allowedOrigins: ["http://127.0.0.1:5050", "http://localhost:5050"],
    allowPublicTargets: false,
    enableCommandExecution: false,
    maxCommandMs: 12000,
    auditLog: true
  }, readJson(CONFIG_PATH, {}));
}

function loadChecks() {
  return readJson(CHECKS_PATH, []).filter((check) => {
    return check && /^[a-z0-9_-]+$/.test(check.id || "") && Array.isArray(check.commands);
  });
}

function send(res, statusCode, body, origin) {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer"
  };
  if (origin) {
    headers["Access-Control-Allow-Origin"] = origin;
    headers["Vary"] = "Origin";
  }
  res.writeHead(statusCode, headers);
  res.end(JSON.stringify(body, null, 2));
}

function allowedOrigin(req, config) {
  const origin = req.headers.origin || "";
  if (!origin) return "";
  if (config.allowedOrigins.includes(origin)) return origin;
  if (origin === "null" && config.allowedOrigins.includes("null")) return "null";
  return false;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = "";
    req.on("data", (chunk) => {
      raw += chunk;
      if (raw.length > 1024 * 128) {
        reject(new Error("Request body too large"));
        req.destroy();
      }
    });
    req.on("end", () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch (error) {
        reject(new Error("Invalid JSON body"));
      }
    });
    req.on("error", reject);
  });
}

function isPrivateHost(host) {
  if (!host || typeof host !== "string") return false;
  const clean = host.trim().toLowerCase();
  if (clean === "localhost") return true;
  if (net.isIP(clean) === 4) {
    const parts = clean.split(".").map(Number);
    return parts[0] === 10 ||
      (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) ||
      (parts[0] === 192 && parts[1] === 168) ||
      (parts[0] === 169 && parts[1] === 254) ||
      parts[0] === 127;
  }
  return /^[a-z0-9.-]+\.local$/.test(clean) || /^[a-z0-9.-]+\.lan$/.test(clean);
}

function validateDevice(device, config) {
  const errors = [];
  const host = String(device.host || "").trim();
  const username = String(device.username || "").trim();
  const port = Number(device.port || 22);
  const sshKeyPath = String(device.sshKeyPath || "").trim();

  if (!/^[a-z0-9._-]{1,64}$/i.test(username)) errors.push("Username is required and must be simple text.");
  if (!/^[a-z0-9._:-]{2,255}$/i.test(host)) errors.push("Host is required and must be an IP, hostname, .local, or .lan name.");
  if (!Number.isInteger(port) || port < 1 || port > 65535) errors.push("SSH port must be between 1 and 65535.");
  if (!config.allowPublicTargets && !isPrivateHost(host)) errors.push("Public targets are blocked by default. Use VPN, private IP, .local, or .lan.");
  if (sshKeyPath && !fs.existsSync(sshKeyPath)) errors.push("SSH key path does not exist on this machine.");
  return { errors, host, username, port, sshKeyPath };
}

function normalizeCommand(command) {
  return ` ${String(command || "").trim().replace(/\s+/g, " ").toLowerCase()} `;
}

function validateCommands(commands) {
  const errors = [];
  for (const command of commands) {
    const normalized = normalizeCommand(command);
    if (!command || /[;&|`$<>]/.test(command)) errors.push(`Blocked unsafe shell characters in command: ${command}`);
    if (CHANGE_WORDS.some((word) => normalized.includes(word))) errors.push(`Blocked non-read-only command: ${command}`);
  }
  return errors;
}

function audit(config, event) {
  if (!config.auditLog) return;
  fs.mkdirSync(LOG_DIR, { recursive: true });
  const date = new Date().toISOString().slice(0, 10);
  const safeEvent = Object.assign({}, event, {
    id: crypto.randomBytes(6).toString("hex"),
    at: new Date().toISOString()
  });
  fs.appendFileSync(path.join(LOG_DIR, `audit-${date}.jsonl`), `${JSON.stringify(safeEvent)}\n`);
}

function readAuditLogs(limit) {
  if (!fs.existsSync(LOG_DIR)) return [];
  const files = fs.readdirSync(LOG_DIR)
    .filter((name) => /^audit-\d{4}-\d{2}-\d{2}\.jsonl$/.test(name))
    .sort()
    .reverse()
    .slice(0, 7);
  const rows = [];
  for (const file of files) {
    const fullPath = path.join(LOG_DIR, file);
    const lines = fs.readFileSync(fullPath, "utf8").split(/\r?\n/).filter(Boolean).reverse();
    for (const line of lines) {
      try {
        const item = JSON.parse(line);
        rows.push({
          at: item.at,
          action: item.action,
          checkId: item.checkId,
          host: item.host,
          username: item.username,
          commandCount: item.commandCount,
          dryRun: item.dryRun,
          mode: item.mode
        });
        if (rows.length >= limit) return rows;
      } catch (_error) {
        // Skip a damaged log line and keep the viewer usable.
      }
    }
  }
  return rows;
}

function runSshCommand(device, command, timeoutMs) {
  return new Promise((resolve) => {
    const args = [
      "-p", String(device.port),
      "-o", "BatchMode=yes",
      "-o", "StrictHostKeyChecking=accept-new",
      "-o", "ConnectTimeout=8"
    ];
    if (device.sshKeyPath) args.push("-i", device.sshKeyPath);
    args.push(`${device.username}@${device.host}`, command);

    const child = spawn("ssh", args, { windowsHide: true, shell: false });
    let stdout = "";
    let stderr = "";
    const timer = setTimeout(() => {
      child.kill();
      stderr += "\nCommand timed out.";
    }, timeoutMs);

    child.stdout.on("data", (data) => { stdout += data.toString(); });
    child.stderr.on("data", (data) => { stderr += data.toString(); });
    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({ command, code, stdout: stdout.slice(0, 60000), stderr: stderr.slice(0, 12000) });
    });
    child.on("error", (error) => {
      clearTimeout(timer);
      resolve({ command, code: -1, stdout, stderr: error.message });
    });
  });
}

async function handleRunCheck(req, res, config, origin) {
  const body = await readBody(req);
  const checks = loadChecks();
  const check = checks.find((item) => item.id === body.checkId);
  if (!check) return send(res, 404, { ok: false, error: "Unknown check id" }, origin);

  const device = validateDevice(body.device || {}, config);
  const commandErrors = validateCommands(check.commands);
  if (device.errors.length || commandErrors.length) {
    return send(res, 400, { ok: false, errors: device.errors.concat(commandErrors) }, origin);
  }

  const dryRun = body.dryRun !== false || !config.enableCommandExecution;
  audit(config, {
    action: "run-check",
    checkId: check.id,
    host: device.host,
    username: device.username,
    commandCount: check.commands.length,
    dryRun,
    mode: config.mode
  });

  if (dryRun) {
    return send(res, 200, {
      ok: true,
      dryRun: true,
      message: "Dry run only. No device connection was opened.",
      check,
      commands: check.commands
    }, origin);
  }

  const results = [];
  for (const command of check.commands) {
    results.push(await runSshCommand(device, command, config.maxCommandMs));
  }
  send(res, 200, { ok: true, dryRun: false, check, results }, origin);
}

function createServer() {
  const config = loadConfig();
  const server = http.createServer(async (req, res) => {
    const origin = allowedOrigin(req, config);
    if (origin === false) return send(res, 403, { ok: false, error: "Origin not allowed" }, "");

    if (req.method === "OPTIONS") {
      res.writeHead(204, {
        "Access-Control-Allow-Origin": origin || "",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Max-Age": "600"
      });
      return res.end();
    }

    try {
      const url = new URL(req.url, `http://${req.headers.host || "127.0.0.1"}`);
      if (req.method === "GET" && url.pathname === "/health") {
        return send(res, 200, {
          ok: true,
          name: "NetWolf Local Agent",
          mode: config.mode,
          bind: config.bind,
          port: config.port,
          cloudEgress: false,
          externalHttp: false,
          readOnlyAllowlist: true,
          commandExecutionEnabled: !!config.enableCommandExecution
        }, origin);
      }
      if (req.method === "GET" && url.pathname === "/checks") {
        return send(res, 200, { ok: true, checks: loadChecks() }, origin);
      }
      if (req.method === "GET" && url.pathname === "/security-report") {
        return send(res, 200, {
          ok: true,
          safety: {
            localOnlyDefault: config.bind === "127.0.0.1",
            publicTargetsBlocked: !config.allowPublicTargets,
            commandExecutionDefaultOff: !config.enableCommandExecution,
            noCloudUploadFromAgent: true,
            noExternalApiCallsFromAgent: true,
            credentialsStored: false,
            auditLogLocalOnly: !!config.auditLog
          }
        }, origin);
      }
      if (req.method === "GET" && url.pathname === "/logs") {
        const limit = Math.max(1, Math.min(100, Number(url.searchParams.get("limit") || 30)));
        return send(res, 200, {
          ok: true,
          logs: readAuditLogs(limit),
          note: "Only local NetWolf agent audit metadata is returned. Secrets and command output are not logged."
        }, origin);
      }
      if (req.method === "POST" && url.pathname === "/run-check") {
        return await handleRunCheck(req, res, config, origin);
      }
      send(res, 404, { ok: false, error: "Not found" }, origin);
    } catch (error) {
      send(res, 500, { ok: false, error: error.message }, origin);
    }
  });
  return { server, config };
}

if (require.main === module) {
  const { server, config } = createServer();
  server.listen(config.port, config.bind, () => {
    console.log(`NetWolf agent listening on http://${config.bind}:${config.port}`);
    console.log("Command execution is", config.enableCommandExecution ? "ENABLED" : "OFF (dry-run only)");
  });
}

module.exports = { createServer };

# NetWolf Local Agent

This is the Level 2 connector for NetWolf Toolkit.

## Option 1: Local agent

Run this on the engineer laptop or customer workstation:

```powershell
cd C:\Users\abaya\Downloads\netwolf-agent
node server.js
```

Open this health URL:

```text
http://127.0.0.1:5051/health
```

Default safety:

- Listens only on `127.0.0.1`.
- Does not upload firewall output to the internet.
- Does not call Groq, Claude, OpenAI, Firebase, or any other external API.
- Starts in dry-run mode, so no SSH connection is opened until `enableCommandExecution` is set to `true`.
- Allows only private targets by default.
- Keeps audit logs locally in `logs`.
- Does not store passwords, API tokens, or device credentials.

## Option 2: Internal jump-server agent

Use the same files on an internal MSP/NOC jump server. Keep it behind VPN or LAN only.

Recommended changes in `config.json`:

```json
{
  "mode": "jump-server",
  "bind": "127.0.0.1",
  "port": 5051,
  "allowedOrigins": ["https://your-internal-netwolf.example"],
  "allowPublicTargets": false,
  "enableCommandExecution": false
}
```

For production, place it behind an internal HTTPS reverse proxy with authentication and logging. Do not expose this port directly to the public internet.

## Enabling real read-only SSH checks

Dry-run is the default. When you are ready:

1. Create a read-only FortiGate admin or SSH key user.
2. Put the key on the local machine.
3. Set `"enableCommandExecution": true` in `config.json`.
4. Restart the agent.
5. Use the NetWolf Assistant Level 2 panel.

The command list is controlled by `checks.json`.
